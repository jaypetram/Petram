package com.petram.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.aventstack.extentreports.ExtentTest;
import com.petram.testng.api.base.ProjectSpecificMethods;

public class Petram_LoginPage extends ProjectSpecificMethods {
	public Petram_LoginPage(RemoteWebDriver driver, ExtentTest test, ExtentTest node) {
		this.driver = driver;
		this.test = test;
		this.node = node;
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(id="username") private WebElement eleUsername;
	@FindBy(id="pwd") private WebElement elePassword;
	@FindBy(linkText="LOGIN") private WebElement eleLoginButton;
	@FindBy(xpath="//div[contains(@class,'alert-animate alert')]") private WebElement eleErrorMsg;
	
	public Petram_LoginPage enterUsername(String data) {
		clearAndType(eleUsername, data);
		return this;
	}
	public Petram_LoginPage enterPassword(String data) {
		clearAndType(elePassword, data);
		return this;
	}
	public Petram_AI_Recommendation clickLoginButton() {
		click(eleLoginButton);
		return new Petram_AI_Recommendation(driver, test, node);
	}
	public Petram_LoginPage clickLoginButtonForNegative() {
		click(eleLoginButton);
		return this;
	}
	public void verifyErrorMessage(String data) {
		verifyPartialText(eleErrorMsg, data);
	}
}
