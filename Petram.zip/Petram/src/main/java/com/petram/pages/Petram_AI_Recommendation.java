package com.petram.pages;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.petram.testng.api.base.ProjectSpecificMethods;

public class Petram_AI_Recommendation extends ProjectSpecificMethods {
	public Petram_AI_Recommendation(RemoteWebDriver driver, ExtentTest test, ExtentTest node) {
		this.driver = driver;
		this.test = test;
		this.node = node;
		PageFactory.initElements(driver, this);
	}

	
}
