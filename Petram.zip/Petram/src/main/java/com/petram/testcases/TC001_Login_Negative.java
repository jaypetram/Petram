package com.petram.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.petram.pages.Petram_LoginPage;
import com.petram.testng.api.base.ProjectSpecificMethods;

public class TC001_Login_Negative extends ProjectSpecificMethods{

	@BeforeTest
	public void setData() {
		testCaseName="Petram Login";
		testDescription = "This Testcase login in to the application";
		authors = "Jeyaram";
		category="smoke";
		dataSheetName="TC002";
		nodes="Negative Flow";
	}
	
	@Test(dataProvider="fetchData",dependsOnMethods="com.petram.testcases.TC001_Login_Positive.runTC001")
	public void runTC002(String username, String password, String errormsg) {
		new Petram_LoginPage(driver, test, node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButtonForNegative()
		.verifyErrorMessage(errormsg);
	}
}
